
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import BlogPreview from './components/BlogPreview';
import Testimonial from './components/Testimonial';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-gray-300">
      <Header />
      <main className="flex-grow">
        <Hero />
        <Features />
        <BlogPreview />
        <Testimonial />
        <div className="container mx-auto px-5 py-12">
           <Newsletter />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
