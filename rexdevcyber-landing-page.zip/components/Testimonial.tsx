
import React from 'react';

const Testimonial: React.FC = () => {
  return (
    <div className="py-20 bg-gray-800">
      <div className="container mx-auto px-5">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-2xl md:text-3xl font-light italic text-white mb-6">
            "A network for storing online account information"
          </p>
          <div className="flex items-center justify-center">
            <img className="w-12 h-12 rounded-full mr-4" src="https://picsum.photos/40/40" alt="CEO" />
            <div className="text-left">
              <p className="font-bold text-white">REXDEV CYBER</p>
              <p className="text-blue-400">CEO, Pomodoro</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Testimonial;
