import React from 'react';

interface BlogCardProps {
  image: string;
  category: string;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  readTime: string;
}

const BlogCard: React.FC<BlogCardProps> = ({ image, category, title, excerpt, author, date, readTime }) => (
  <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden h-full flex flex-col group transform hover:-translate-y-2 transition-transform duration-300">
    <img className="w-full h-48 object-cover" src={image} alt={title} />
    <div className="p-6 flex-grow flex flex-col">
      <span className="bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full mb-4 self-start">{category}</span>
      <h3 className="text-xl font-bold text-white mb-3 flex-grow group-hover:text-blue-400 transition-colors duration-300">
        <a href="#">{title}</a>
      </h3>
      <p className="text-gray-400 mb-6">{excerpt}</p>
      <div className="mt-auto flex items-center pt-4 border-t border-gray-700">
        <img className="w-10 h-10 rounded-full mr-4" src="https://picsum.photos/40" alt={author} />
        <div>
          <p className="text-white font-semibold">{author}</p>
          <p className="text-gray-500 text-sm">{date} &middot; {readTime}</p>
        </div>
      </div>
    </div>
  </div>
);

const BlogPreview: React.FC = () => {
  const blogPosts = [
    {
      image: 'https://i.postimg.cc/cH9CpPg8/Untitled-1.png',
      category: 'News',
      title: 'Starting development',
      excerpt: 'A network for storing online account information which may be a fiber network that stores many other types of statistics and traffic database block.',
      author: 'JOKREX ALLDAY',
      date: 'March 12, 2023',
      readTime: '6 min read',
    },
    {
      image: 'https://i.postimg.cc/pLnqR21Q/blog3.png',
      category: 'Media',
      title: 'Fundraising support',
      excerpt: 'Fundraising support and joining the developer group To increase the efficiency of development to the maximum.',
      author: 'JOKREX ALLDAY',
      date: 'March 23, 2023',
      readTime: '4 min read',
    },
    {
      image: 'https://i.postimg.cc/3rLfYf9B/blog1.png',
      category: 'News',
      title: 'The last blog post title is a little bit longer than the others',
      excerpt: 'Adding resources and combining resources to use for analysis and close the loopholes of the system to be strong.',
      author: 'JOKREX ALLDAY',
      date: 'April 2, 2023',
      readTime: '10 min read',
    },
  ];

  return (
    <section id="blog" className="bg-gray-900 py-20 scroll-mt-24">
      <div className="container mx-auto px-5">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white">From our blog</h2>
          <p className="text-lg text-gray-400 mt-4 max-w-2xl mx-auto">
            Discover insights, news, and stories from our team of experts.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <BlogCard key={index} {...post} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogPreview;