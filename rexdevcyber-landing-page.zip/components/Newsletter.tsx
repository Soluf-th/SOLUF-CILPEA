import React from 'react';

const Newsletter: React.FC = () => {
  return (
    <aside id="contact" className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-lg p-8 md:p-12 scroll-mt-24">
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 items-center">
        <div className="text-center xl:text-left">
          <h3 className="text-3xl font-bold text-white mb-2">New products, delivered to you.</h3>
          <p className="text-blue-200">Sign up for our newsletter for the latest updates.</p>
        </div>
        <div>
          <form className="flex flex-col sm:flex-row gap-2">
            <input
              type="email"
              placeholder="Email address..."
              aria-label="Email address"
              className="w-full px-4 py-3 rounded-md text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white"
            />
            <button
              type="submit"
              className="bg-white text-blue-600 font-semibold py-3 px-6 rounded-md hover:bg-gray-200 transition duration-300"
            >
              Sign up
            </button>
          </form>
          <p className="text-sm text-blue-200 mt-3 text-center sm:text-left">
            We care about privacy, and will never share your data.
          </p>
        </div>
      </div>
    </aside>
  );
};

export default Newsletter;