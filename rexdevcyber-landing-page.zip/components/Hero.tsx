import React from 'react';

const Hero: React.FC = () => {
  return (
    <header id="home" className="bg-gray-800 py-20 scroll-mt-20">
      <div className="container mx-auto px-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
              A network for storing online account information
            </h1>
            <p className="text-lg text-gray-400 mb-8">
              Which may be a fiber network that stores many other types of statistics and traffic database block.
            </p>
            <div className="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
              <a
                href="#"
                className="bg-blue-600 text-white font-semibold py-3 px-8 rounded-lg hover:bg-blue-700 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg"
              >
                Register
              </a>
              <a
                href="#"
                className="bg-gray-700 text-white font-semibold py-3 px-8 rounded-lg hover:bg-gray-600 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg"
              >
                Login
              </a>
              <a
                href="#about"
                className="bg-transparent border-2 border-gray-600 text-gray-300 font-semibold py-3 px-8 rounded-lg hover:border-gray-400 hover:text-white transition duration-300 ease-in-out transform hover:scale-105 shadow-lg"
              >
                Learn More
              </a>
            </div>
          </div>
          <div className="hidden lg:block text-center">
            <img 
              src='https://i.postimg.cc/cH9CpPg8/Untitled-1.png' 
              alt='Network graphic' 
              className="w-full h-auto max-w-lg mx-auto rounded-lg shadow-2xl animate-pulse-slow"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Hero;