import React, { useState } from 'react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Blog', href: '#blog' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className="bg-gray-800 sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto px-5">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-4">
            <img src='https://i.postimg.cc/1tMhvgCQ/logorexdevcyber.png' alt='REXDEVCYBER Logo' className="h-10 w-10" />
            <a href="#home" className="text-2xl font-bold text-white tracking-wider">REXDEVCYBER</a>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            {navLinks.map((link) => (
              <a key={link.name} href={link.href} className="text-gray-300 hover:text-white transition duration-300">{link.name}</a>
            ))}
            <a href="#" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-300">Login</a>
          </div>
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-300 hover:text-white focus:outline-none">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden px-5 pb-4 space-y-2">
          {navLinks.map((link) => (
            <a key={link.name} href={link.href} className="block text-gray-300 hover:text-white transition duration-300 py-2">{link.name}</a>
          ))}
          <a href="#" className="block w-full text-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-300 mt-2">Login</a>
        </div>
      )}
    </nav>
  );
};

export default Header;